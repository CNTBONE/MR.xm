
@interface UIWindow (Private)
- (unsigned int)_contextId;
@end