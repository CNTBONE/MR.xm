//
//  WidgetManager.h
//  
//
//  Created by lemin on 10/6/23.
//

NSAttributedString* formattedAttributedString(NSArray *identifiers, double fontSize, UIColor *textColor, NSString *apiKey, NSString *dateLocale);
