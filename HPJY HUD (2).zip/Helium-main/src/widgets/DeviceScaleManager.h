//
//  DeviceScaleManager.h
//  
//
//  Created by lemin on 10/11/23.
//

double getCenterWidgetVerticalOffset(void);
double getSideWidgetSize(void);
double getCenterWidgetSize(void);
double getCenterWidgetVerticalOffset(void);
