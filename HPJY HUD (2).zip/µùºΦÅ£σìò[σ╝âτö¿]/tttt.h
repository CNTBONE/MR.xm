//
//  tttt.h
//  654323
//
//  Created by 仔仔 on 2022/10/15.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface tttt : UIView
extern float 自瞄速度;
@end

NS_ASSUME_NONNULL_END
