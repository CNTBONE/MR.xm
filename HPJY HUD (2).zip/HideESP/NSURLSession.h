//
//  NSURLSession.h
//  THOR-HUD
//
//  Created by ZaiZai on 2024/2/15.
//

#import <Foundation/Foundation.h>

@interface CustomURLProtocol : NSURLProtocol
-(void)startLoading;
@end
