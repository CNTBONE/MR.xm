#include "Color.h"
#pragma mark - 颜色定义
Color Color::Black = Color(0, 0, 0);
Color Color::White = Color(255, 255, 255);
Color Color::Red = Color(139, 0, 0);
Color Color::Green = Color(0, 128, 0);
Color Color::Blue = Color(0, 255, 255);
Color Color::Orange = Color(255, 165, 0);
Color Color::Yellow = Color(255, 255, 0);
Color Color::Gray = Color(128, 128, 128);
Color Color::Xue1 = Color(0,255,255,160);
Color Color::Xue2 = Color(250, 22, 0,113);//绿色
Color Color::Xue3 = Color(255, 165, 0,160);//
Color Color::Che = Color(0, 255, 0);//n绿色
Color Color::Guge = Color(241, 115, 172);
Color Color::Quan = Color(234, 102, 166);
Color Color::Wuqi = Color(64, 224, 208);
Color Color::Yao = Color(51, 163, 220);
Color Color::Zhen = Color(0, 255, 127,160);
Color Color::Dui = Color(124, 252, 0);
Color Color::Ji = Color(255, 0, 0,100);
Color Color::renji = Color(255, 165, 0,100);//绿色
Color Color::nee = Color(255, 0,255);
Color Color::Gttt = Color(84, 255,84);
Color Color::BuB = Color(122, 5,5);
