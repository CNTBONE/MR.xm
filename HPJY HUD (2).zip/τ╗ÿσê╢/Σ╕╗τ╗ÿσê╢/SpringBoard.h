
#import <Foundation/Foundation.h>
#include <arm_neon.h>
NS_ASSUME_NONNULL_BEGIN
//#define kAimRadius 100

@interface ReadMV : UIView


@end

NS_ASSUME_NONNULL_END
