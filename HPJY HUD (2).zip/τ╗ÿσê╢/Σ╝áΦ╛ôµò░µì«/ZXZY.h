
#ifndef ______h
#define ______h


#endif /* ______h */

//#import

extern float ZX;
extern float ZY;
extern float ZX2;
extern float ZY2;

extern float XDis;


@interface Constants : NSObject {
    
}
@end
