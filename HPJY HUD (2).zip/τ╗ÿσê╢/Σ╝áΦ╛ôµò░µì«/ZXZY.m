
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "ZXZY.h"
float ZX= 0;//
float ZY= 0;//
float ZX2= 0;//
float ZY2= 0;//


float XDis = 0;

@implementation Constants
@end
