//
//  PUBGDataModel.m
//  ChatsNinja
//
//  Created by TianCgg on 2022/10/2.
//

#import "PUBGDataModel.h"

@implementation PUBGPlayerBone

@end

@implementation PUBGPlayerModel

@end
