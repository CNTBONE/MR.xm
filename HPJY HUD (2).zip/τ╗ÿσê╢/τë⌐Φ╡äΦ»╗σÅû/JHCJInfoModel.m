

#import "JHCJInfoModel.h"

@implementation JHCJInfoModel



@end
