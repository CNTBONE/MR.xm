#import <UIKit/UIKit.h>



@interface MGPGLabel : UILabel

@property (nonatomic, strong) UIColor *borderColor;
@property (nonatomic, assign) CGFloat borderWidth;
@end

