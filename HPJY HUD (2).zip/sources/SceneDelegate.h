//
//  SceneDelegate.h
//  UItable
//
//  Created by yanyan on 2023/2/28.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

