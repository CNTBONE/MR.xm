

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface GCLocalNotification : NSObject

+ (void)设置通知内容;

+ (void)注册通知;

@end
